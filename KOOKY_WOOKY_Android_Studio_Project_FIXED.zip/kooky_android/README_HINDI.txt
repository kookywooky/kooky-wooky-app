KOOKY WOOKY Android App project

IMPORTANT:
1. Website URL app mein https://kookywooky.netlify.app set hai.
2. Agar ye custom Netlify URL abhi activate nahi hua, MainActivity.java mein HOME ko current live website URL se replace karein.
3. Android Studio mein is folder ko Open karein.
4. Gradle sync hone dein.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK app/build/outputs/apk/debug/app-debug.apk mein milega.

Customer install ke liye debug APK share kiya ja sakta hai, lekin public Play Store release ke liye signed release build banana hoga.

Project WebView wrapper hai: orders, Razorpay checkout aur website updates live website se hi chalenge. Is project ko build/test kiye bina APK ko production-ready na samjhein.
